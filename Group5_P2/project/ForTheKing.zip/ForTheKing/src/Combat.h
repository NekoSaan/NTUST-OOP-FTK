#ifndef _COMBAT_H_
#define _COMBAT_H_

#include "Entity.h"

// combat function to let other file call
void combat(std::vector<Entity*> role, std::vector<Entity*> enemy);
	
#endif // _COMBAT_H_